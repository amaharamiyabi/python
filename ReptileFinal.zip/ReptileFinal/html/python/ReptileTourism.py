from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess
import json


app = Flask(__name__)
CORS(app)  # 啟用 CORS，允許跨來源請求

@app.route('/submit_data', methods=['POST'])
def submit_data():
    # 接收前端發送的純文字資料
    input_data = request.data.decode('utf-8')

    # 將輸入資料傳遞給爬蟲程式，並等待結果
    try:
        # 运行爬虫脚本，传递输入数据给爬虫程序
        result = subprocess.run(
            ['python', './html/python/Crawl.py', input_data],  # 传递输入数据给爬虫程序
            capture_output=True,
            text=True,
            check=True  # 如果爬虫脚本失败，抛出异常
        )

        # 获取爬虫的输出结果
        crawl_output = json.loads(result.stdout)  # 解析爬虫返回的 JSON 数据
        return jsonify(crawl_output)  # 返回给前端

    except subprocess.CalledProcessError as e:
        return jsonify({"error": "爬蟲程序執行失敗", "details": str(e)}), 500
    except json.JSONDecodeError as e:
        return jsonify({"error": "解析爬蟲返回的 JSON 失敗", "details": str(e)}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
