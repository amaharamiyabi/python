from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import sys

# 瀏覽器選項
options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.binary_location = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"

# 輸入中文名稱進行導航

def navigate_and_extract(driver, location_name, xpath_mapping):
    try:
        # 展開父選單
        parent_menu = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.menu-item-has-children > a'))
        )
        driver.execute_script("arguments[0].click();", parent_menu)

        # 點擊對應的選項
        location_xpath = xpath_mapping.get(location_name)
        #if not location_xpath:
            #raise ValueError(f"找不到名稱『{location_name}』的對應 XPATH")

        location_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, location_xpath))
        )
        driver.execute_script("arguments[0].click();", location_element)

        # 初始化頁數
        page_number = 1
        all_data = []

        while True:
            # 等待頁面加載完成
            WebDriverWait(driver, 10).until(lambda d: d.execute_script("return document.readyState") == "complete")

            # 確認是否進入最後一頁
            if "Oops! That page can’t be found." in driver.page_source:
                #print("已到最後一頁，停止抓取。")
                break

            # 抓取頁面內所有文章的資料
            articles = driver.find_elements(By.CSS_SELECTOR, "article")

            for article in articles:
                try:
                    # 抓取標題
                    title_element = article.find_element(By.CSS_SELECTOR, "h2 a")
                    title = title_element.text
                    link = title_element.get_attribute("href")

                    # 抓取內容
                    try:
                        content_element = article.find_elements(By.CSS_SELECTOR, "p, font[style*='vertical-align']")
                        content = "\n".join([e.text for e in content_element if e.text.strip()]) if content_element else "無內容"
                    except Exception:
                        content = "無內容"

                    # 抓取圖片
                    try:
                        image_element = article.find_element(By.CSS_SELECTOR, "img")
                        image = image_element.get_attribute("src")
                    except Exception:
                        image = "無圖片"

                    all_data.append({
                        "title": title,
                        "link": link,
                        "content": content,
                        "image": image
                    })
                except Exception as e:
                    print(f"跳過一篇文章，錯誤: {e}")

            # 嘗試進入下一頁
            try:
                page_number += 1
                next_page_url = f"/page/{page_number}/"
                driver.get(driver.current_url.rstrip('/') + next_page_url)
            except Exception as e:
                #print(f"無法進入下一頁: {e}")
                break

        return all_data
    except Exception as e:
        raise RuntimeError("error")
        #raise RuntimeError(f"導航到『{location_name}』時失敗: {e}")

# 主程式
if __name__ == "__main__":
    driver = webdriver.Chrome(options=options)
    url = "https://markandhazyl.com/"
    driver.get(url)

    # 測試用 XPATH 映射表
    xpath_mapping = {
            "日本": "//*[@id=\"menu-item-104507\"]/a",
            "北海道": "//*[@id=\"menu-item-104511\"]/a",
            "東北地區": "//*[@id=\"menu-item-104513\"]/a",
            "關東地區": "//*[@id=\"menu-item-104516\"]/a",
            "中部地區": "//*[@id=\"menu-item-104509\"]/a",
            "近畿地區": "//*[@id=\"menu-item-104515\"]/a",
            "中國地區": "//*[@id=\"menu-item-104508\"]/a",
            "四國地區": "//*[@id=\"menu-item-104512\"]/a",
            "九州地區": "//*[@id=\"menu-item-104510\"]/a",
            "沖繩": "//*[@id=\"menu-item-104514\"]/a",
            "台灣": "//*[@id=\"menu-item-104391\"]/a",
            "台北": "//*[@id=\"menu-item-104392\"]/a",
            "桃園": "//*[@id=\"menu-item-104395\"]/a",
            "新竹": "//*[@id=\"menu-item-104394\"]/a",
            "宜蘭": "//*[@id=\"menu-item-104393\"]/a",
            "苗栗": "//*[@id=\"menu-item-104396\"]/a",
            "台中": "//*[@id=\"menu-item-104397\"]/a",
            "彰化": "//*[@id=\"menu-item-104398\"]/a",
            "雲林": "//*[@id=\"menu-item-104400\"]/a",
            "南投": "//*[@id=\"menu-item-104399\"]/a",
            "花蓮": "//*[@id=\"menu-item-104401\"]/a",
            "嘉義": "//*[@id=\"menu-item-104403\"]/a",
            "台南": "//*[@id=\"menu-item-104402\"]/a",
            "高雄": "//*[@id=\"menu-item-104406\"]/a",
            "屏東": "//*[@id=\"menu-item-104405\"]/a",
            "台東": "//*[@id=\"menu-item-104404\"]/a",
            "離島": "//*[@id=\"menu-item-104407\"]/a",
            "韓國": "//*[@id=\"menu-item-104551\"]/a",
            "首爾": "//*[@id=\"menu-item-104572\"]/a",
            "釜山": "//*[@id=\"menu-item-104571\"]/a",
            "大邱": "//*[@id=\"menu-item-104569\"]/a",
            "濟州島": "//*[@id=\"menu-item-104570\"]/a",
            "泰國": "//*[@id=\"menu-item-104679\"]/a",
            "曼谷": "//*[@id=\"menu-item-104674\"]/a",
            "普吉島": "//*[@id=\"menu-item-104678\"]/a",
            "芭達雅": "//*[@id=\"menu-item-104681\"]/a",
            "清邁": "//*[@id=\"menu-item-104683\"]/a",
            "華欣": "//*[@id=\"menu-item-104685\"]/a",
            "亞洲": "//*[@id=\"menu-item-104554\"]/a",
            "馬來西亞": "//*[@id=\"menu-item-104553\"]/a",
            "新加坡": "//*[@id=\"menu-item-104557\"]/a",
            "越南": "//*[@id=\"menu-item-104550\"]/a",
            "印尼": "//*[@id=\"menu-item-104556\"]/a",
            "菲律賓": "//*[@id=\"menu-item-104549\"]/a",
            "中國": "//*[@id=\"menu-item-104555\"]/a",
            "香港": "//*[@id=\"menu-item-104552\"]/a",
            "澳門": "//*[@id=\"menu-item-104548\"]/a",
            "紐澳": "//*[@id=\"menu-item-104413\"]/a",
            "紐西蘭": "//*[@id=\"menu-item-104415\"]/a",
            "澳洲": "//*[@id=\"menu-item-104414\"]/a",
            "歐洲": "//*[@id=\"menu-item-104417\"]/a",
            "英國": "//*[@id=\"menu-item-104423\"]/a",
            "義大利": "//*[@id=\"menu-item-104422\"]/a",
            "法國": "//*[@id=\"menu-item-104420\"]/a",
            "德國": "//*[@id=\"menu-item-104419\"]/a",
            "瑞士": "//*[@id=\"menu-item-104421\"]/a",
            "冰島": "//*[@id=\"menu-item-104418\"]/a",
    }

    try:

        # 從命令列參數接收輸入地區名稱
        if len(sys.argv) < 2:
            raise ValueError("請提供地區名稱作為參數")

        location_name = sys.argv[1]

        result = navigate_and_extract(driver, location_name, xpath_mapping)

        # 返回爬取結果作為 JSON
        print(json.dumps(result))

    except Exception as e:
        # 返回錯誤訊息
        print(json.dumps("error"))

    finally:
        if 'driver' in locals():
            driver.quit()